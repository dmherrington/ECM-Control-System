#include "fault_register_three.h"

FaultRegisterThree::FaultRegisterThree()
{

}
