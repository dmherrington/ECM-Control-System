#ifndef FAULT_REGISTER_THREE_H
#define FAULT_REGISTER_THREE_H


class FaultRegisterThree
{
public:
    FaultRegisterThree();
};

#endif // FAULT_REGISTER_THREE_H