#ifndef EXCEPTION_RESPONSE_H
#define EXCEPTION_RESPONSE_H


class ExceptionResponse
{
public:
    ExceptionResponse();
};

#endif // EXCEPTION_RESPONSE_H