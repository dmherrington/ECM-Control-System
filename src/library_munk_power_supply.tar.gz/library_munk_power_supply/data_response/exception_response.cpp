#include "exception_response.h"

ExceptionResponse::ExceptionResponse()
{

}
