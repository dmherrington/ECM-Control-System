#ifndef FAULT_REGISTER_ONE_H
#define FAULT_REGISTER_ONE_H


class FaultRegisterOne
{
public:
    FaultRegisterOne();
};

#endif // FAULT_REGISTER_ONE_H