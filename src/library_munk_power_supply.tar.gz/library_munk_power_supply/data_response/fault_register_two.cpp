#include "fault_register_two.h"

FaultRegisterTwo::FaultRegisterTwo()
{

}
