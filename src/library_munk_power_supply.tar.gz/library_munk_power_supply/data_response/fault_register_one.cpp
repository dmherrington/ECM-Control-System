#include "fault_register_one.h"

FaultRegisterOne::FaultRegisterOne()
{

}
