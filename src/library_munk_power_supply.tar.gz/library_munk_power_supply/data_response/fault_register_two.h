#ifndef FAULT_REGISTER_TWO_H
#define FAULT_REGISTER_TWO_H


class FaultRegisterTwo
{
public:
    FaultRegisterTwo();
};

#endif // FAULT_REGISTER_TWO_H