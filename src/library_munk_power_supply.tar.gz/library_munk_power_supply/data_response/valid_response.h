#ifndef VALID_RESPONSE_H
#define VALID_RESPONSE_H


class ValidResponse
{
public:
    ValidResponse();
};

#endif // VALID_RESPONSE_H