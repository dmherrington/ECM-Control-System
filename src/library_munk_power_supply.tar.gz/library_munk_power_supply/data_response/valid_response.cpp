#include "valid_response.h"

ValidResponse::ValidResponse()
{

}
