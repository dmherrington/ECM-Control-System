#ifndef I_LINK_EVENTS_H
#define I_LINK_EVENTS_H

#include <cstdlib>
#include <vector>
#include <string>

namespace munk {
namespace comms{

class ILink;

class ILinkEvents
{
public:

    virtual void ConnectionOpened() const = 0;

    virtual void ConnectionClosed() const = 0;

    virtual void ReceiveData(ILink *link_ptr, const std::vector<uint8_t> &buffer) const = 0;

    virtual void CommunicationError(const ILink* link_ptr, const std::string &type, const std::string &msg) const = 0;
};

} //end of namespace comms
} //end of namespace munk

#endif // I_LINK_EVENTS_H
