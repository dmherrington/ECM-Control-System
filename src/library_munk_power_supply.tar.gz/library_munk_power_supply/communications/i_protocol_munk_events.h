#ifndef I_PROTOCOL_MUNK_EVENTS_H
#define I_PROTOCOL_MUNK_EVENTS_H

#include <string>
#include <memory>

#include "i_link.h"

namespace munk {
namespace comms{

//!
//! \brief Interface that it to be implemented by users of munk comms to listen for any events it fired
//!
class IProtocolMunkEvents
{
public:
    //!
    //! \brief MessageReceived
    //! \param link_ptr
    //!
    virtual void MessageReceived(const ILink* link_ptr) const = 0;
};


} //end of namespace comms
} //end of namespace munk

#endif // I_PROTOCOL_MUNK_EVENTS_H
