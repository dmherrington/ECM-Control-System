#include "munk_serial_link.h"

#include <functional>

#include <QCoreApplication>
#include <QTimer>

namespace munk {
namespace comms{

//!
//! \brief This class defines a thread such that a QObject can run in peace.
//!
class AppThread : public QThread
{
public:
    AppThread(const size_t interval, std::function<void()> func)
    {
        if(QCoreApplication::instance() == NULL)
        {
            int argc = 0;
            char * argv[] = {(char *)"sharedlib.app"};
            pApp = new QCoreApplication(argc, argv);
        }

        m_Interval = interval;
        m_Func = func;
    }

    virtual void run()
    {
        QTimer *timer = new QTimer(0);
        timer->moveToThread(this);
        pApp->connect(timer, &QTimer::timeout, m_Func);
        timer->start(m_Interval);

        exec();
    }

private:

    QCoreApplication *pApp;

    std::function<void()> m_Func;
    size_t m_Interval;
};

MunkSerialLink::MunkSerialLink()
{
    connected = false;
    std::cout << "Create MunkSerialLink " <<std::endl;
}

MunkSerialLink::~MunkSerialLink()
{
    Disconnect();

}

bool MunkSerialLink::Connect(void)
{
    Disconnect();

    QSerialPort::SerialPortError    error;
    QString                         errorString;

    // Initialize the connection
    if (!_hardwareConnect(error, errorString)) {
        if (_config.isAutoConnect()) {
            // Be careful with spitting out open error related to trying to open a busy port using autoconnect
            if (error == QSerialPort::PermissionError) {
                // Device already open, ignore and fail connect
                return false;
            }
        }

        _emitLinkError("Error connecting: Could not create port. " + errorString.toStdString());
        return false;
    }
    return true;
}

bool MunkSerialLink::Disconnect(void)
{
    if (m_port) {
        m_port->close();
        delete m_port;
        m_port = NULL;
    }

    if(connected)
    {
        GReturn rtnCode = GClose(galil);
        if(rtnCode == G_NO_ERROR)
        {
            this->connected = false;
            EmitEvent([](const ILinkEvents *ptr){ptr->ConnectionClosed();});

        }
    }
    return this->connected;
}

bool MunkSerialLink::isConnected() const
{
    return this->connected;
}

GReturn MunkSerialLink::UploadProgram(const std::string &programText) const
{
    GReturn rtn = GProgramDownload(galil,programText.c_str(),0);
    return rtn;
}

GReturn MunkSerialLink::DownloadProgram(const std::string &programText) const
{

}

GReturn MunkSerialLink::WriteTellErrorCode(char *errorDescription) const
{
    GSize read_bytes = 0; //bytes read in GCommand
    std::string newCommand = "TC 1";
    GReturn rtn = GCommand(galil,newCommand.c_str(),errorDescription,sizeof(errorDescription),&read_bytes);
    return rtn;
}

GReturn MunkSerialLink::WriteCommand(const std::string &command) const
{
    //GReturn rtn = GCmd(galil,command.c_str());
    //return rtn;
}

GReturn MunkSerialLink::WriteRequest(const AbstractRequestPtr request) const
{
    std::cout<<"We are trying to write a request here: "<<RequestToString(request->getRequestType())<<std::endl;
    GSize read_bytes = 0; //bytes read in GCommand
    char* buf = request->getBuffer(); //buffer to be allocated for the response
    std::string commandString = request->getRequestString();

    GReturn rtn = GCommand(galil,commandString.c_str(),buf,sizeof(buf),&read_bytes);
    request->updateTime();
    return rtn;
}

void MunkSerialLink::_readBytes(void)
{
    qint64 byteCount = m_port->bytesAvailable();
    if (byteCount) {
        QByteArray buffer;
        buffer.resize(byteCount);
        m_port->read(buffer.data(), buffer.size());

        std::vector<uint8_t> vec_buffer = std::vector<uint8_t>(buffer.begin(), buffer.end());

        EmitEvent([this,&vec_buffer](const ILinkEvents *ptr){ptr->ReceiveData(this, vec_buffer);});
    }
}

void MunkSerialLink::linkError(QSerialPort::SerialPortError error)
{
    switch (error) {
    case QSerialPort::NoError:
        break;
    case QSerialPort::ResourceError:
        EmitEvent([this](const ILinkEvents *ptr){ptr->ConnectionRemoved(this);});
        break;
    default:
        // You can use the following qDebug output as needed during development. Make sure to comment it back out
        // when you are done. The reason for this is that this signal is very noisy. For example if you try to
        // connect to a PixHawk before it is ready to accept the connection it will output a continuous stream
        // of errors until the Pixhawk responds.
        //std::cout << "SerialLink::linkError" << error;
        break;
    }
}

void MunkSerialLink::_emitLinkError(const std::string& errorMsg) const
{
    std::string msg = "Error on link " + getPortName() + ". " + errorMsg;
    EmitEvent([&](const ILinkEvents *ptr){ptr->CommunicationError(this, "Link Error", msg);});
}

void MunkSerialLink::PortEventLoop()
{
    if(m_port->bytesAvailable())
        this->_readBytes();



    if(m_port->errorString() != "")
    {
        linkError(m_port->error());
    }
}

} //end of namespace comms
} //end of namespace munk
