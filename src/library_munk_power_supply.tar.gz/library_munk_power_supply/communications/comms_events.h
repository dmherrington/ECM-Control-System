#ifndef COMMS_EVENTS_H
#define COMMS_EVENTS_H

#include <string>
#include "common/common.h"

namespace munk {
namespace comms{

class CommsEvents
{
public:

    /////////////////////////////////////////////////////////
    /// Link Events
    /////////////////////////////////////////////////////////

    virtual void LinkConnected() const
    {

    }

    virtual void LinkDisconnected() const
    {

    }

    virtual void StatusMessage(const std::string &msg)
    {
        UNUSED(msg);
    }

    virtual void NewStatusPosition(const Status_Position &status)
    {
        UNUSED(status);
    }

    virtual void NewStatusMotorEnabled(const Status_MotorEnabled &status)
    {
        UNUSED(status);
    }

    virtual void NewStatusMotorInMotion(const Status_AxisInMotion &status)
    {
        UNUSED(status);
    }

};

} //end of namespace comms
} //end of namespace munk

#endif // COMMS_EVENTS_H
