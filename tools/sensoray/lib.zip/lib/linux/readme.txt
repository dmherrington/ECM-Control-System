For best results, build Linux .a files with "makelib" in Linux examples directory
