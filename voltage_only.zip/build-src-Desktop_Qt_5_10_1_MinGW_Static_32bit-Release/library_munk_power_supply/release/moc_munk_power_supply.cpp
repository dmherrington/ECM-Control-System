/****************************************************************************
** Meta object code from reading C++ file 'munk_power_supply.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.10.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../src/library_munk_power_supply/munk_power_supply.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'munk_power_supply.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.10.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MunkPowerSupply_t {
    QByteArrayData data[20];
    char stringdata0[304];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MunkPowerSupply_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MunkPowerSupply_t qt_meta_stringdata_MunkPowerSupply = {
    {
QT_MOC_LITERAL(0, 0, 15), // "MunkPowerSupply"
QT_MOC_LITERAL(1, 16, 27), // "signal_MunkConnectionUpdate"
QT_MOC_LITERAL(2, 44, 0), // ""
QT_MOC_LITERAL(3, 45, 38), // "common::comms::CommunicationC..."
QT_MOC_LITERAL(4, 84, 5), // "value"
QT_MOC_LITERAL(5, 90, 25), // "signal_CommunicationError"
QT_MOC_LITERAL(6, 116, 11), // "std::string"
QT_MOC_LITERAL(7, 128, 4), // "type"
QT_MOC_LITERAL(8, 133, 3), // "msg"
QT_MOC_LITERAL(9, 137, 26), // "signal_CommunicationUpdate"
QT_MOC_LITERAL(10, 164, 4), // "name"
QT_MOC_LITERAL(11, 169, 24), // "signal_FaultCodeRecieved"
QT_MOC_LITERAL(12, 194, 6), // "regNum"
QT_MOC_LITERAL(13, 201, 20), // "signal_SegmentSetAck"
QT_MOC_LITERAL(14, 222, 23), // "signal_SegmentException"
QT_MOC_LITERAL(15, 246, 2), // "RW"
QT_MOC_LITERAL(16, 249, 7), // "meaning"
QT_MOC_LITERAL(17, 257, 27), // "signal_SegmentWriteProgress"
QT_MOC_LITERAL(18, 285, 9), // "completed"
QT_MOC_LITERAL(19, 295, 8) // "required"

    },
    "MunkPowerSupply\0signal_MunkConnectionUpdate\0"
    "\0common::comms::CommunicationConnection\0"
    "value\0signal_CommunicationError\0"
    "std::string\0type\0msg\0signal_CommunicationUpdate\0"
    "name\0signal_FaultCodeRecieved\0regNum\0"
    "signal_SegmentSetAck\0signal_SegmentException\0"
    "RW\0meaning\0signal_SegmentWriteProgress\0"
    "completed\0required"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MunkPowerSupply[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   49,    2, 0x06 /* Public */,
       5,    2,   52,    2, 0x06 /* Public */,
       9,    2,   57,    2, 0x06 /* Public */,
      11,    2,   62,    2, 0x06 /* Public */,
      13,    1,   67,    2, 0x06 /* Public */,
      14,    2,   70,    2, 0x06 /* Public */,
      17,    2,   75,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 6, 0x80000000 | 6,    7,    8,
    QMetaType::Void, 0x80000000 | 6, 0x80000000 | 6,   10,    8,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 6,   12,    8,
    QMetaType::Void, 0x80000000 | 6,    8,
    QMetaType::Void, 0x80000000 | 6, 0x80000000 | 6,   15,   16,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   18,   19,

       0        // eod
};

void MunkPowerSupply::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MunkPowerSupply *_t = static_cast<MunkPowerSupply *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->signal_MunkConnectionUpdate((*reinterpret_cast< const common::comms::CommunicationConnection(*)>(_a[1]))); break;
        case 1: _t->signal_CommunicationError((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const std::string(*)>(_a[2]))); break;
        case 2: _t->signal_CommunicationUpdate((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const std::string(*)>(_a[2]))); break;
        case 3: _t->signal_FaultCodeRecieved((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const std::string(*)>(_a[2]))); break;
        case 4: _t->signal_SegmentSetAck((*reinterpret_cast< const std::string(*)>(_a[1]))); break;
        case 5: _t->signal_SegmentException((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const std::string(*)>(_a[2]))); break;
        case 6: _t->signal_SegmentWriteProgress((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< common::comms::CommunicationConnection >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (MunkPowerSupply::*_t)(const common::comms::CommunicationConnection & ) const;
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MunkPowerSupply::signal_MunkConnectionUpdate)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (MunkPowerSupply::*_t)(const std::string & , const std::string & ) const;
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MunkPowerSupply::signal_CommunicationError)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (MunkPowerSupply::*_t)(const std::string & , const std::string & ) const;
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MunkPowerSupply::signal_CommunicationUpdate)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (MunkPowerSupply::*_t)(const int & , const std::string & ) const;
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MunkPowerSupply::signal_FaultCodeRecieved)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (MunkPowerSupply::*_t)(const std::string & ) const;
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MunkPowerSupply::signal_SegmentSetAck)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (MunkPowerSupply::*_t)(const std::string & , const std::string & ) const;
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MunkPowerSupply::signal_SegmentException)) {
                *result = 5;
                return;
            }
        }
        {
            typedef void (MunkPowerSupply::*_t)(const int & , const int & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MunkPowerSupply::signal_SegmentWriteProgress)) {
                *result = 6;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MunkPowerSupply::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_MunkPowerSupply.data,
      qt_meta_data_MunkPowerSupply,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MunkPowerSupply::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MunkPowerSupply::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MunkPowerSupply.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "CommsEvents"))
        return static_cast< CommsEvents*>(this);
    if (!strcmp(_clname, "MunkStatusCallback_Interface"))
        return static_cast< MunkStatusCallback_Interface*>(this);
    return QObject::qt_metacast(_clname);
}

int MunkPowerSupply::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void MunkPowerSupply::signal_MunkConnectionUpdate(const common::comms::CommunicationConnection & _t1)const
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(const_cast< MunkPowerSupply *>(this), &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MunkPowerSupply::signal_CommunicationError(const std::string & _t1, const std::string & _t2)const
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(const_cast< MunkPowerSupply *>(this), &staticMetaObject, 1, _a);
}

// SIGNAL 2
void MunkPowerSupply::signal_CommunicationUpdate(const std::string & _t1, const std::string & _t2)const
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(const_cast< MunkPowerSupply *>(this), &staticMetaObject, 2, _a);
}

// SIGNAL 3
void MunkPowerSupply::signal_FaultCodeRecieved(const int & _t1, const std::string & _t2)const
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(const_cast< MunkPowerSupply *>(this), &staticMetaObject, 3, _a);
}

// SIGNAL 4
void MunkPowerSupply::signal_SegmentSetAck(const std::string & _t1)const
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(const_cast< MunkPowerSupply *>(this), &staticMetaObject, 4, _a);
}

// SIGNAL 5
void MunkPowerSupply::signal_SegmentException(const std::string & _t1, const std::string & _t2)const
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(const_cast< MunkPowerSupply *>(this), &staticMetaObject, 5, _a);
}

// SIGNAL 6
void MunkPowerSupply::signal_SegmentWriteProgress(const int & _t1, const int & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
